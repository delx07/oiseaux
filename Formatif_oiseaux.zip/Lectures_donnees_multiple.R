Lectures_donnees_m=function(fichier){
  
  files = list.files(path = fichier, pattern = ".csv", full.names = TRUE)
  
  # Créez un dataframe vide pour stocker les données combinées
  combined_data = data.frame()
  
  for (file in files) {
    # Lire le fichier CSV
    data <- read.csv(file, header = TRUE, sep=",")  
    # Ajouter les données au dataframe combiné
    combined_data <- bind_rows(combined_data, data)  
  }
  return(combined_data)
}




