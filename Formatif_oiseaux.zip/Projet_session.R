library(dplyr)
library(RSQLite)
library(DBI)
library(lubridate)
source("Lectures_donnees_multiple.R")

data_oiseaux=Lectures_donnees_m("acoustique_oiseaux")

#Change le format des dates de dd/mm/yyyy à yyyy-mm-dd
data_oiseaux$date_obs=dmy(data_oiseaux$date_obs)
#Change le nouveaux type de donnée de la fonction précédente en char
data_oiseaux$date_obs=as.character(data_oiseaux$date_obs)

#Nettoyage à faire pour les NULL en NA
data_oiseaux[data_oiseaux== "NULL"]=NA
#data_oiseaux[is.na(data_oiseaux)]="NULL"

#Création de 4 data frame représentant les 4 tables SQL de la base de données, 
#moins les ID uniques qui seront générés avec la table. On ne fait que sélectionné
#les colonnes pertinentes
data_site=data_oiseaux[ , c("site_id", "lat")]
data_temps=data_oiseaux[ , c("date_obs","time_start","time_finish","time_obs")]
data_taxonomie=data_oiseaux[ , c("kingdom","phylum","class","order","family","genus","valid_scientific_name","vernacular_en","vernacular_fr","species","rank")]
data_principale=data_oiseaux[ , c("site_id","variable")]

#Monte le nom avec le working directory pour se connecter à la base de données
d=getwd()
n="oiseaux.db"
z=paste(d,n)
#Ouvre la connection à la base de donnée nommée oiseaux.db par l'objet oiseaux_db
oiseaux_bd = dbConnect(RSQLite::SQLite(), dbname=z)

#Crée la table temps sous forme d'un char pour être utilisé dans la fonction dbSendQuery
creer_temps = "CREATE TABLE temps (
        id_temps      INTEGER PRIMARY KEY AUTOINCREMENT,
        time_start    TIME,
        time_finish   TIME,
        date_obs      DATE,
        time_obs      TIME
    );"

#Envoie la demande à RSQLite pour la création de la table temps par l'objet 
#oiseaux_bd qui nous lie à la base de donnée oiseaux.db
dbSendQuery(oiseaux_bd, creer_temps)

#Crée la table taxonomie sous forme d'un char pour être utilisé dans la fonction dbSendQuery
creer_taxonomie = "CREATE TABLE taxonomie (
        id_taxonomie              INTEGER PRIMARY KEY AUTOINCREMENT,
        valid_scientific_name     VARCHAR(80),
        rank                      VARCHAR(80),
        kingdom                   VARCHAR(80),
        phylum                    VARCHAR(80),
        class                     VARCHAR(80),
        ordre                     VARCHAR(80),
        family                    VARCHAR(80),
        genus                     VARCHAR(80),
        species                   VARCHAR(80),
        vernacular_en             VARCHAR(80),
        vernacular_fr             VARCHAR(80)
    );"

#Envoie la demande à RSQLite pour la création de la table taxonomie par l'objet 
#oiseaux_bd qui nous lie à la base de donnée oiseaux.db
dbSendQuery(oiseaux_bd, creer_taxonomie)

#Crée la table site sous forme d'un char pour être utilisé dans la fonction dbSendQuery
creer_site = "CREATE TABLE site (
        id_site           INTEGER,
        lat               DOUBLE,
        PRIMARY KEY (id_site)
    );"

#Envoie la demande à RSQLite pour la création de la table principale par l'objet 
#oiseaux_bd qui nous lie à la base de donnée oiseaux.db
dbSendQuery(oiseaux_bd, creer_site)

#Crée la table principale sous forme d'un char pour être utilisé dans la fonction dbSendQuery
creer_principale = "CREATE TABLE principale (
        id_site           INTEGER,
        id_taxonomie      INTEGER,
        id_temps          INTEGER,
        variable          VARCHAR(20),
        PRIMARY KEY (id_site, id_taxonomie, id_temps),
        FOREIGN KEY (id_taxonomie) REFERENCES taxonomie(id_taxonomie),
        FOREIGN KEY (id_temps) REFERENCES temps(id_temps),
        FOREIGN KEY (id_site) REFERENCES site(id_site)
    );"

#Envoie la demande à RSQLite pour la création de la table principale par l'objet 
#oiseaux_bd qui nous lie à la base de donnée oiseaux.db
dbSendQuery(oiseaux_bd, creer_principale)


#Nous déconnecte de la base de données oiseaux.db pour permettre 
#l'accès à un autre utilisateur
dbDisconnect(oiseaux_bd)

